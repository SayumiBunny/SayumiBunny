Licence Kaito Bot 2021.

1. You can't use your own credits.
2. You can modify the code, but do not edit the credits.
3. You can't redistribute the code.
4. You can use this code for personal use only. Not commercial.
5. If using this code for a Discord Bot, you may only use this code for a private bot. Not public.


What counts as credits?

1. The footer in the help command linking Flo's repl.it.
2. The licence file.
3. Any notes stating ownership of the code.

You may not remove these credits if using this code.


This code is the property of: flo0003, dok4440.